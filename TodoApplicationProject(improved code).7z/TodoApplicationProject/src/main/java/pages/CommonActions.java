package pages;

public class CommonActions {


}
