package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class PersonalInfoPage {


    public By emailTextBox = By.id("cl_login");

    public By emailTextBoxByCSS = By.cssSelector("#cl_login.c24-uli-input");
    public By weiterButtoninPersönlicheAngaben = By.xpath("//a[@class='Buttonstyles__ButtonExtend-sc-od5j0-0 Buttonstyles__DialogButton-sc-od5j0-3 cKRCAs kcYhrV LoadingButtonstyles__ButtonWrapper-sc-15z9avq-0 kpMHRw styles__ButtonDialog-sc-1solng-2 iNTuJe']");


    public String email = "mars@yopmail.com";

    public int xCoordinateOfEmailTextBox =  500;
    public int yCoordinateOfEmailTextBox =  410;


    public String emailTextBoxJavaScriptShadowRoot = "document.querySelector('unified-login').shadowRoot.querySelector('#cl_login')";


    /*
    note: I could not locate the HTML element "text box of the email" by ID or xpath and I tried many  times  in the browser inspector page and I did not get it.

    the following are the xpath I tried:

    (//*[@id='cl_login'])[3]

   //*[@type='email']


    after searching on internet  it seems like it is Pseudo-elements which don't exist in the DOM tree (hence the name)

    reference:

    https://stackoverflow.com/questions/51992258/xpath-to-find-pseudo-element-after-in-side-a-div-element-with-out-any-content

    https://stackoverflow.com/questions/63845698/how-to-write-the-xpath-for-an-element-where-before-tag-is-involved


update:
reference: https://www.lambdatest.com/blog/handling-pseudo-elements-in-css-with-selenium/
Why NoSuchElementError?

Although the locator is correct, you cannot work with the pseudo-elements with normal Selenium locators.
This is because the pseudo-elements in CSS on a webpage are treated as a JavaScript element. It means that these pseudo-elements in CSS are executed in the front-end at runtime when the page loads and not initially.


    */



}
