package pages;

import org.testng.Assert;
import helper.DriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Check24CreditCardComparisonPage {

    DriverFactory driverFactory = new DriverFactory();

    ChromeDriver driver = (ChromeDriver) driverFactory.getDriver();


    public String homepage_URL = "https://finanzen.check24.de/accounts/d/kreditkarte/result.html";


    public By cookieButton = By.xpath("(//*[@class='c24-cookie-consent-button'])[1]");
    public By closePopupWindowButton = By.xpath("//*[@class='credit-score__close']");

    public By firstZumAntragButton = By.xpath("(//a[contains(text(), 'zum Antrag')])[1]");

 public By personalInformationLabel = By.xpath("//h2[text()='Persönliche Angaben']");
    public String cookieName = "ppset";
    public String expectedCookieValue = "kreditkarte";

    public Check24CreditCardComparisonPage() throws InterruptedException {
    }

    public boolean chooseCreditCard() {

        checkCookie();
        driver.findElement(firstZumAntragButton).click();


        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // 20 is the timeout in seconds

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("unified-login")));
        String emailtTextBoxJSScript = "return document.querySelector('unified-login').shadowRoot.querySelector('#cl_login')";
        WebElement emailTextBox = (WebElement) jsExecutor.executeScript(emailtTextBoxJSScript);
        wait.until(ExpectedConditions.elementToBeClickable(emailTextBox));
        emailTextBox.sendKeys("mars@yopmail.com");


        String submitEmailButtonJSScript = "return document.querySelector('unified-login').shadowRoot.querySelector('button')";
        WebElement submitEmailButton = (WebElement) jsExecutor.executeScript(submitEmailButtonJSScript);
        submitEmailButton.click();


        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("unified-login")));
        String IchmöchteRadioButtonJSScript = "return document.querySelector('unified-login').shadowRoot.querySelectorAll('.c24-uli-cl-box-option')[1]";
        WebElement IchmöchteRadioButton = (WebElement) jsExecutor.executeScript(IchmöchteRadioButtonJSScript);
        wait.until(ExpectedConditions.elementToBeClickable(IchmöchteRadioButton));
        IchmöchteRadioButton.click();


        String weiterButtonJSScript = "return document.querySelector('unified-login').shadowRoot.querySelector('#c24-uli-register-btn')";
        WebElement weiterButton = (WebElement) jsExecutor.executeScript(weiterButtonJSScript);
        wait.until(ExpectedConditions.elementToBeClickable(weiterButton));
        weiterButton.click();

        boolean isPersonalInformationLabelDisplayed = driver.findElement(personalInformationLabel).isDisplayed();
        return isPersonalInformationLabelDisplayed;

    }

    public boolean checkCookie() {
        driver.get("https://finanzen.check24.de/accounts/d/kreditkarte/result.html");

        driver.findElement(cookieButton).click();

        // driver.findElement(closePopupWindowButton).click();

        String actualCookieValue = driver.manage().getCookieNamed(cookieName).getValue();
        boolean isCookiesSet = actualCookieValue.equals(expectedCookieValue);
        Assert.assertTrue(isCookiesSet);
        return isCookiesSet;

    }
}

