package pages;

import helper.Constants;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

import static helper.Constants.API_URL;

@Log4j2
public class CreditCardAPI {

    public int VerifyCreditResponse(String id) {
        String endPoint = API_URL + id;
        log.info("end point = " + endPoint);
        Response response = RestAssured.get(endPoint);
        log.info("Check the HTTP status code\n ");
        return response.statusCode();
    }
}
