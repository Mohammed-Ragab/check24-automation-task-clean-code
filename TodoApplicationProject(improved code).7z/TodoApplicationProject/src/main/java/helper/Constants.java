package helper;

public class Constants {

    public static final String API_URL = "https://finanzen.check24.de/accounts/r/frs/productInfo/kreditkarte/";


}
