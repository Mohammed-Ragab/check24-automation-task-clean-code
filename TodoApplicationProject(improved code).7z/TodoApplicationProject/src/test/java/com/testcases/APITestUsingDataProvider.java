package com.testcases;
import com.sun.jna.WString;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class APITestUsingDataProvider {


    @DataProvider(name = "test-data")
    public String[] dataProvFunc(){
        return new String []{
                "200007", "abcd", "5456"
        };
    }


}
