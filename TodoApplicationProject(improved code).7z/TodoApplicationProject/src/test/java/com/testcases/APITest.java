package com.testcases;
import lombok.extern.log4j.Log4j2;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CreditCardAPI;
import com.testcases.testhelper.TestData;


@Log4j2
public class APITest {

    @Test(dataProvider = "test-data", dataProviderClass = TestData.class)
    public void testEndpoints(String id, int expectedResult) {
        CreditCardAPI creditCardAPI = new CreditCardAPI();
        int statusCode = creditCardAPI.VerifyCreditResponse(id);
        log.info(statusCode);
        System.out.println("test the log");
        Assert.assertEquals(statusCode, expectedResult);

    }
}
