package com.testcases.testhelper;

import org.testng.annotations.DataProvider;

public class TestData {

    @DataProvider(name = "test-data")
    public Object[][] dataProvFunc() {
        return new Object[][]{
                {"6342", 204}, {"200007", 200}, {"abcd", 404}, {"5456", 204}
        };
    }
}
