package com.testcases;

import com.testcases.testhelper.TestConfig;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.Check24CreditCardComparisonPage;
import pages.PersonalInfoPage;

import java.time.Duration;

public class CreditCardTest extends TestConfig {

   TestConfig testConfig = new TestConfig();
    Check24CreditCardComparisonPage check24CreditCardComparisonPage = new Check24CreditCardComparisonPage();

    PersonalInfoPage personalInfoPage = new PersonalInfoPage();

    public CreditCardTest() throws InterruptedException {
    }

    @Test
    public void testCreditCardApplication() {
        Assert.assertTrue(check24CreditCardComparisonPage.chooseCreditCard());
        //testConfig.tearDown();



    }


}
